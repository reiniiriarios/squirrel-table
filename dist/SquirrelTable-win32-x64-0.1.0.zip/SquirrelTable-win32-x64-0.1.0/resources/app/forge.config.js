const fs = require('fs');
const zip = require('adm-zip');
const pjson = require('./package.json');
module.exports = {
    packagerConfig: {
        "icon": "build/icons/icon.ico"
    },
    makers: [
        {
            name: "@electron-forge/maker-squirrel",
            config: {
                name: "SquirrelTable",
                iconUrl: "file:///c:/code/squirrel-table/build/icons/icon.ico"
            }
        },
        {
            name: "@electron-forge/maker-zip",
            platforms: [
                "darwin"
            ]
        },
        {
            name: "@electron-forge/maker-deb",
            config: {}
        },
        {
            name: "@electron-forge/maker-rpm",
            config: {}
        }
    ],
    hooks: {
        postMake: async (outputs) => {
            let name = 'SquirrelTable-win32-x64';
            let vName =  name + '-' + pjson.version
            let out = 'out/';
            fs.rename(out + name,out + vName,() => {
                fs.mkdir(vName + '/sql', () => {
                    fs.copyFile('.env.sample', out + vName + '/.env.sample', () => {
                        let zipFile = new zip();
                        zipFile.addLocalFolder(out + vName, vName);
                        zipFile.writeZip('dist/' + vName + '.zip');
                    });
                });
            });
        }
    }
}