SELECT
	t1.*
	FROM (SELECT
		COUNT(p.entity_id) AS num_products,
		uvp.vendor_id AS maker_id,
		m.vendor_name AS maker_name,
		m.email AS maker_email,
		CASE WHEN a.value LIKE '%5456%' THEN 'listed' ELSE '' END AS free_shipping_listed,
		CASE WHEN a2.value = 1 THEN 'enabled' ELSE '' END AS custom_shipping_options_enabled,
		CASE
			WHEN a2.value = 1 AND rates.delivery_type_id = 7 THEN 'free shipping'
			WHEN a2.value = 1 AND rates2.delivery_type_id = 4 THEN 'free delivery'
			ELSE '' END
			AS free_shipping_custom_shipping_enabled,
		JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.firstname')) AS first_name,
		JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.lastname')) AS last_name,
		s.name AS region_name
		FROM catalog_product_entity p
		LEFT JOIN catalog_product_entity_varchar a
			ON a.row_id = p.row_id AND a.attribute_id = 217
		LEFT JOIN catalog_product_entity_int a2
			ON a2.row_id = p.row_id AND a2.attribute_id = 194
		LEFT JOIN udtiership_product_rates rates
			ON rates.product_id = p.entity_id AND rates.delivery_type_id = 7
		LEFT JOIN udtiership_product_rates rates2
			ON rates2.product_id = p.entity_id AND rates2.delivery_type_id = 4
		LEFT JOIN udropship_vendor_product_assoc uvp
			ON uvp.product_id = p.entity_id AND uvp.vendor_id IS NOT NULL
		LEFT JOIN udropship_vendor m
			ON uvp.vendor_id = m.vendor_id
		LEFT JOIN store s
			ON m.store_id = s.store_id
		WHERE
			m.status = 'A'
		GROUP BY maker_id, custom_shipping_options_enabled, free_shipping_custom_shipping_enabled
	) t1
	WHERE
		free_shipping_listed = 'listed' OR free_shipping_custom_shipping_enabled != ''
	ORDER BY t1.maker_name ASC;