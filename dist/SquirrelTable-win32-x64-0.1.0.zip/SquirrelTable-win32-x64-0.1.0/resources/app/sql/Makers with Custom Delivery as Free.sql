SELECT
	t1.*
	FROM (SELECT
		m.vendor_id AS maker_id,
		m.vendor_name AS maker_name,
		CASE
			WHEN m.tiership_use_v2_rates = 1 THEN 'yes'
			ELSE 'no' END
			AS use_specific_rates,
		CASE
			WHEN tier.delivery_type_id = 4 THEN 'free delivery'
			WHEN tier.delivery_type_id = 7 THEN 'free shipping'
			ELSE '' END
			AS specific_rate
		FROM udropship_vendor m
		INNER JOIN udtiership_vendor_simple_rates tier
			ON tier.vendor_id = m.vendor_id
	) t1
	WHERE specific_rate != '' AND use_specific_rates = 'yes'
	ORDER BY t1.maker_name ASC;