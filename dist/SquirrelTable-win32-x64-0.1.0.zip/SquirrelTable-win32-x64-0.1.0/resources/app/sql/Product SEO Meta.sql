SELECT
	product.entity_id AS product_id,
	product.sku,
	title_table.title,
	meta_title_table.meta_title,
	description_table.description,
	meta_description_table.meta_description
	FROM catalog_product_entity product
	LEFT JOIN (
		SELECT
		product_varchar.row_id AS product_id,
		product_varchar.value AS title
		FROM catalog_product_entity_varchar product_varchar
		WHERE product_varchar.attribute_id = 73
	) title_table
	ON product.entity_id = title_table.product_id
	LEFT JOIN (
		SELECT
		product_varchar.row_id AS product_id,
		product_varchar.value AS meta_title
		FROM catalog_product_entity_varchar product_varchar
		WHERE product_varchar.attribute_id = 84
	) meta_title_table
	ON product.entity_id = meta_title_table.product_id
	LEFT JOIN (
		SELECT
		product_text.row_id AS product_id,
		product_text.value AS description
		FROM catalog_product_entity_text product_text
		WHERE product_text.attribute_id = 75
	) description_table
	ON product.entity_id = description_table.product_id
	LEFT JOIN (
		SELECT
		product_text.row_id AS product_id,
		product_text.value AS meta_description
		FROM catalog_product_entity_text product_text
		WHERE product_text.attribute_id = 76
	) meta_description_table
	ON product.entity_id = meta_description_table.product_id
	WHERE title_table.title IS NOT NULL
	AND (
		meta_description_table.meta_description IS NULL
		OR meta_title_table.meta_title IS NULL
	)
	ORDER BY product_id ASC
	;