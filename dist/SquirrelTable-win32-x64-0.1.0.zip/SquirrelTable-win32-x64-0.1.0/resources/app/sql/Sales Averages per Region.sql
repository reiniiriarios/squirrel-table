SELECT
	r.name AS region,
	COUNT(s.entity_id) AS num_orders_above_zero,
	ROUND(AVG(s.grand_total),2) AS average_grand_total,
	ROUND(AVG(s.shipping_amount),2) AS average_shipping_amount,
	ROUND(AVG(s.tax_amount),2) AS average_tax_amount,
	ROUND(AVG(s.total_item_count),2) AS average_num_products,
	ROUND(AVG(s.customer_is_guest) * 100,2) AS percentage_guest_checkouts,
	ROUND(AVG(s.base_gift_cards_amount > 0) * 100,2) AS percentage_gift_card_used
	FROM sales_order s
	LEFT JOIN store r
	ON r.store_id = s.store_id
	WHERE s.grand_total > 0
	GROUP BY region
	ORDER BY region ASC;