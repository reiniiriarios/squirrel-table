SELECT
	m.vendor_id AS maker_id,
	m.vendor_name AS maker_name,
	p.entity_id AS product_id,
	p.sku,
	CASE
		WHEN cpa.category_id IS NULL THEN 'FALSE'
		ELSE 'true' END
		AS no_checkout
	FROM udropship_vendor m
	LEFT JOIN udropship_vendor_product_assoc vpa
	ON m.vendor_id = vpa.vendor_id
	LEFT JOIN catalog_product_entity p
	ON vpa.product_id = p.entity_id
	LEFT JOIN catalog_category_product cpa
	ON p.entity_id = cpa.product_id AND cpa.category_id = 140
	WHERE m.udmember_membership_code = 'CBD Maker' AND p.entity_id IS NOT NULL
	ORDER BY no_checkout ASC, maker_name ASC, product_id ASC;