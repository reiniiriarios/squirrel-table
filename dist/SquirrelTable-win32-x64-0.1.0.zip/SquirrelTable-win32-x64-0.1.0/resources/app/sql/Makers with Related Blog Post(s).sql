SELECT
	COUNT(m2.maker_id) AS num_active_makers,
	CASE WHEN m2.blog_id IS NULL OR m2.blog_id = '' THEN 'no' ELSE 'yes' END AS has_related_blog_post
	FROM (SELECT
		m1.vendor_id AS maker_id,
		JSON_UNQUOTE(JSON_EXTRACT(m1.custom_vars_combined,'$.blogid')) AS blog_id
		FROM udropship_vendor m1
		WHERE m1.status = 'A'
	) m2
	GROUP BY has_related_blog_post;
