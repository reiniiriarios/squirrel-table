WITH s AS (SELECT
	po.udropship_vendor AS maker_id,
	ROUND(SUM(po.base_total_value),2) AS sales_items_total,
	ROUND(SUM(po.base_total_value) + SUM(po.base_shipping_amount) + SUM(po.base_tax_amount),2) AS sales_total,
	ROUND(AVG(po.base_total_value + po.base_shipping_amount + po.base_tax_amount),2) AS sales_average,
	ROUND(AVG(po.base_shipping_amount),2) AS shipping_average,
	COUNT(po.entity_id) AS number_of_orders,
	ROUND(SUM(po.total_qty)) AS items_sold
	FROM udropship_po po
	GROUP BY maker_id
)
SELECT
	m.vendor_name AS maker_name,
	m.email AS maker_email,
	r.name AS region,
	s3.*,
	CASE
		WHEN cumulative_percent_rank >= 20 THEN 'A'
		WHEN cumulative_percent_rank >= 5 THEN 'B'
		ELSE 'C' END
		AS abc_group,
	COUNT(p.entity_id) AS number_of_products,
	CASE
		WHEN AVG(price.value) IS NULL THEN 0
		ELSE ROUND(AVG(price.value),2) END
		AS average_product_price
	FROM (SELECT
		s1.*,
		s1.sales_total / (SELECT SUM(sales_total) FROM s) * 100 AS percentage_of_sales,
		s1.number_of_orders / (SELECT SUM(number_of_orders) FROM s) * 100 AS percentage_of_orders,
		SUM(s2.sales_total) / (SELECT SUM(sales_total) FROM s) * 100 AS cumulative_percent_rank
		FROM s s1, s s2
		WHERE s1.sales_total >= s2.sales_total
			OR (s1.sales_total = s2.sales_total AND s1.maker_id = s2.maker_id)
		GROUP BY s1.maker_id, s1.sales_total
	) s3
	LEFT JOIN udropship_vendor m
		ON m.vendor_id = s3.maker_id
	LEFT JOIN store r
		ON m.store_id = r.store_id
	LEFT JOIN udropship_vendor_product_assoc vpa
		ON s3.maker_id = vpa.vendor_id
	LEFT JOIN catalog_product_entity p
		ON vpa.product_id = p.entity_id
	LEFT JOIN catalog_product_entity_decimal price
		ON p.row_id = price.row_id AND price.attribute_id = 77
	GROUP BY s3.maker_id
	ORDER BY s3.sales_total DESC;