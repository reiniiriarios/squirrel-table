SELECT
	m3.*,
	COUNT(m3.endicia_status) AS num_makers
	FROM (
		SELECT
		m2.shipping_carrier,
		m2.ups_account_status,
		CASE WHEN m2.shipping_carrier = 'ups' AND m2.ups_thirdparty_account <>'' THEN 'third party account found' ELSE '' END AS ups_third_party,
		CASE WHEN m2.shipping_carrier = 'fedex' AND m2.fedex_user_key <>'' THEN 'user key found' ELSE '' END AS fedex_account_status,
		CASE WHEN m2.shipping_carrier = 'fedex' AND m2.fedex_thirdparty_account <>'' THEN 'third party account found' ELSE '' END AS fedex_third_party,
		CASE WHEN m2.shipping_carrier = 'usps' AND m2.endicia_account_id <>'' THEN 'account id found' ELSE '' END AS endicia_status
		FROM (SELECT
			m.carrier_code AS shipping_carrier,
			CASE WHEN m.carrier_code = 'ups' AND m.ups_shipper_number <>'' THEN 'shipper number found' ELSE '' END AS ups_account_status,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.endicia_account_id')) AS endicia_account_id,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.fedex_user_key')) AS fedex_user_key,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.fedex_thirdparty_account_number')) AS fedex_thirdparty_account,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.ups_thirdparty_account_number')) AS ups_thirdparty_account
			FROM udropship_vendor m
		) m2
	) m3
	GROUP BY shipping_carrier, endicia_status, ups_account_status, ups_third_party, fedex_account_status, fedex_third_party
	ORDER BY shipping_carrier ASC
	;
