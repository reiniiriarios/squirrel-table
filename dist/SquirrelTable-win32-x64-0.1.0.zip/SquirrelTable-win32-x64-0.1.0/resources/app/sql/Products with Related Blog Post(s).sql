SELECT
	COUNT(p.row_id) AS num_products,
	CASE WHEN a.attribute_id IS NOT NULL THEN 'yes' ELSE 'no' END AS has_related_blog_post
	FROM catalog_product_entity p
	LEFT JOIN catalog_product_entity_varchar a
	ON p.row_id = a.row_id AND a.attribute_id=253
	GROUP BY has_related_blog_post;
