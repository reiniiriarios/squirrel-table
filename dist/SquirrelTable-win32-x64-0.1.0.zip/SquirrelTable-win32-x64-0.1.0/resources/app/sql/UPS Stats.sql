SELECT
	m2.*,
	CASE
		WHEN ups_shipper_number != '' AND ups_thirdparty_account != '' AND ups_api_url != 'https://www.ups.com/ups.app/xml/' THEN 'invalid api url; third party account number needs validation'
		WHEN ups_shipper_number = '' AND ups_thirdparty_account != '' AND ups_api_url != 'https://www.ups.com/ups.app/xml/' THEN 'invalid api url; dm shipper number missing'
		WHEN ups_shipper_number != '' AND ups_thirdparty_account = '' AND ups_api_url != 'https://www.ups.com/ups.app/xml/' THEN 'invalid api url; third party account number removed'
		WHEN ups_shipper_number != '' AND ups_thirdparty_account = '' AND ups_api_url = 'https://www.ups.com/ups.app/xml/' THEN ''
		WHEN ups_shipper_number != '' AND ups_thirdparty_account != '' THEN 'third party account number needs validation'
		WHEN ups_shipper_number = '' AND ups_thirdparty_account != '' THEN 'dm shipper number missing; third party account number needs validation'
		WHEN ups_api_url IS NULL THEN 'unable to fetch data, verify manually'
		WHEN ups_shipper_number = '' AND ups_thirdparty_account = '' AND ups_api_url = 'https://wwwcie.ups.com/ups.app/xml/' THEN 'incorrect default'
		ELSE '' END
		AS ups_errors
		FROM (SELECT
			m.vendor_id AS maker_id,
			m.vendor_name AS maker_name,
			m.carrier_code AS shipping_carrier,
			m.ups_shipper_number,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.ups_thirdparty_account_number')) AS ups_thirdparty_account,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.ups_api_url')) AS ups_api_url
			FROM udropship_vendor m
			WHERE m.carrier_code = 'ups'
		) AS m2
	ORDER BY maker_id ASC;
