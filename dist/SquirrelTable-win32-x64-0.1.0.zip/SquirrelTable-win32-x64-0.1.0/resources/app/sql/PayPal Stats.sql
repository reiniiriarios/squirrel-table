SELECT
	COUNT(maker.maker_id) AS num_active_makers,
	CASE
		WHEN maker.paypal_email != '' AND maker.paypal_email IS NOT NULL AND maker.paypal_connected = 1 AND maker.paypal_error = 0 THEN 'connected'
		WHEN maker.paypal_email != '' AND maker.paypal_email IS NOT NULL AND maker.paypal_connected = 0 AND maker.paypal_error = 0 THEN 'not connected'
		WHEN (maker.paypal_email = '' OR maker.paypal_email IS NULL) AND maker.paypal_connected = 0 THEN 'no email address'
		WHEN (maker.paypal_email = '' OR maker.paypal_email IS NULL) AND maker.paypal_connected = 1 THEN 'connection error'
		WHEN maker.paypal_error = 1 THEN 'connection error'
		ELSE 'unknown' END
		AS paypal_connection_status
	FROM (SELECT
		maker.vendor_id AS maker_id,
		CASE WHEN maker.uppc_connect_url IS NOT NULL THEN 1 ELSE 0 END AS paypal_connected,
		CASE WHEN maker.uppc_connect_url IS NOT NULL AND maker.uppc_merchant_id IS NULL THEN 1 ELSE 0 END AS paypal_error,
		JSON_UNQUOTE(JSON_EXTRACT(maker.custom_vars_combined,'$.payout_paypal_email')) AS paypal_email
		FROM udropship_vendor maker
		WHERE maker.status = 'A'
	) AS maker
	GROUP BY paypal_connection_status
	ORDER BY num_active_makers DESC;
