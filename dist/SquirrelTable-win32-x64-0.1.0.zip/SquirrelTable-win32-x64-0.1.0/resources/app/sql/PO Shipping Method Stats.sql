SELECT
	COUNT(po.entity_id) AS num_purchase_orders,
	CASE WHEN po.udropship_method_description = '' THEN 'unknown' ELSE po.udropship_method_description END AS shipping_method
	FROM udropship_po po
	GROUP BY po.udropship_method_description
	ORDER BY num_purchase_orders DESC;