SELECT
	t.*
	FROM (SELECT
		m.vendor_id AS maker_id,
		m.email,
		m.vendor_name AS maker_name,
		store.name AS region,
		COUNT(product.product_id) AS num_products,
		SUM(product_status.value = 1) AS num_products_enabled
		FROM udropship_vendor m
		LEFT JOIN udropship_vendor_product_assoc product
		ON m.vendor_id = product.vendor_id
		LEFT JOIN catalog_product_entity product_entity
		ON product.product_id = product_entity.entity_id
		LEFT JOIN catalog_product_entity_int product_status
		ON product_entity.row_id = product_status.row_id AND product_status.attribute_id = 97
		LEFT JOIN store
		ON store.store_id = m.store_id
		LEFT JOIN admin_user users
		ON users.udropship_vendor = m.vendor_id
		WHERE m.status = 'A'
		GROUP BY m.vendor_id
	) AS t
	WHERE t.num_products_enabled = 0 OR t.num_products_enabled IS NULL
	ORDER BY t.maker_id ASC;