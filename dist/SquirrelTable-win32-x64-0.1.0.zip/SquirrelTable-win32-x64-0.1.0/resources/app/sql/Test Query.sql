-- Test query for app, ssh, and mysql validation
select vendor_id, vendor_name
from udropship_vendor
limit 2;