SELECT
	maker.carrier_code AS shipping_carrier,
	COUNT(maker.carrier_code) AS num_makers
	FROM udropship_vendor maker
	GROUP BY shipping_carrier
	ORDER BY num_makers DESC;