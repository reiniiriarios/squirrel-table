SELECT
	COUNT(p.entity_id) AS num_products,
	gm.value AS gift_message_available,
	gw.value AS gift_wrapping_available
	FROM catalog_product_entity p
	LEFT JOIN catalog_product_entity_varchar gm
		ON gm.row_id = p.row_id AND gm.attribute_id = 153
	LEFT JOIN catalog_product_entity_varchar gw
		ON gw.row_id = p.row_id AND gw.attribute_id = 154
	LEFT JOIN udropship_vendor_product_assoc uvp
		ON uvp.product_id = p.entity_id AND uvp.vendor_id IS NOT NULL
	LEFT JOIN udropship_vendor m
		ON uvp.vendor_id = m.vendor_id
	WHERE
		m.status = 'A'
	GROUP BY gift_message_available, gift_wrapping_available;