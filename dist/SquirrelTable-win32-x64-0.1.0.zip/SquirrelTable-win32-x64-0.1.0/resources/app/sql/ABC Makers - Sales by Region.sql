WITH s AS (SELECT
	po.udropship_vendor AS maker_id,
	ROUND(SUM(po.base_total_value),2) AS sales_items_total
	FROM udropship_po po
	GROUP BY maker_id
),
t1 AS (SELECT
	r.name AS region,
	s3.maker_id,
	s3.sales_items_total,
	CASE
		WHEN cumulative_percent_rank >= 20 THEN 'A'
		WHEN cumulative_percent_rank >= 5 THEN 'B'
		ELSE 'C' END
		AS abc_group
	FROM (SELECT
		s1.*,
		SUM(s2.sales_items_total) / (SELECT SUM(sales_items_total) FROM s) * 100 AS cumulative_percent_rank
		FROM s s1, s s2
		WHERE s1.sales_items_total >= s2.sales_items_total
			OR (s1.sales_items_total = s2.sales_items_total AND s1.maker_id = s2.maker_id)
		GROUP BY s1.maker_id, s1.sales_items_total
	) s3
	LEFT JOIN udropship_vendor m
		ON m.vendor_id = s3.maker_id
	LEFT JOIN store r
		ON m.store_id = r.store_id
	LEFT JOIN udropship_vendor_product_assoc vpa
		ON s3.maker_id = vpa.vendor_id
	LEFT JOIN catalog_product_entity p
		ON vpa.product_id = p.entity_id
	LEFT JOIN catalog_product_entity_decimal price
		ON p.row_id = price.row_id AND price.attribute_id = 77
	GROUP BY s3.maker_id, r.name, s3.sales_items_total, s3.cumulative_percent_rank
	ORDER BY s3.sales_items_total DESC
)
SELECT
	SUM(t1.sales_items_total) AS total_sales,
	t1.region,
	t1.abc_group
	FROM t1
	GROUP BY t1.abc_group, t1.region
;