SELECT *
	FROM (SELECT
		maker.*,
		CASE WHEN maker.website REGEXP '^https?:\/\/.+' THEN 'error' ELSE '' END AS website_error,
		CASE WHEN maker.facebook REGEXP '^(?!https?:\/\/(?:www\.)?facebook.com\/).+' THEN 'error' ELSE '' END AS facebook_error,
		CASE WHEN maker.instagram REGEXP '^(?!https?:\/\/(?:www\.)?instagram.com\/).+' THEN 'error' ELSE '' END AS instagram_error,
		CASE WHEN maker.twitter REGEXP '^(?!https?:\/\/(?:www\.)?twitter.com\/).+' THEN 'error' ELSE '' END AS twitter_error,
		CASE WHEN maker.pinterest REGEXP '^(?!https?:\/\/(?:www\.)?pinterest.com\/).+' THEN 'error' ELSE '' END AS pinterest_error,
		CASE WHEN maker.youtube REGEXP '^(?!https?:\/\/(?:www\.)?youtube.com\/channel\/).+' THEN 'error' ELSE '' END AS youtube_error
		FROM (SELECT 
			maker.email,
			maker.vendor_name AS maker_name,
			maker.vendor_id AS maker_id,
			JSON_UNQUOTE(JSON_EXTRACT(maker.custom_vars_combined,'$.website')) AS website,
			JSON_UNQUOTE(JSON_EXTRACT(maker.custom_vars_combined,'$.facebook')) AS facebook,
			JSON_UNQUOTE(JSON_EXTRACT(maker.custom_vars_combined,'$.instagram')) AS instagram,
			JSON_UNQUOTE(JSON_EXTRACT(maker.custom_vars_combined,'$.twitter')) AS twitter,
			JSON_UNQUOTE(JSON_EXTRACT(maker.custom_vars_combined,'$.pinterest')) AS pinterest,
			JSON_UNQUOTE(JSON_EXTRACT(maker.custom_vars_combined,'$.youtube')) AS youtube
			FROM udropship_vendor maker
			WHERE maker.status = 'A'
		) AS maker
	) AS maker
	WHERE maker.website_error != ''
	OR maker.facebook_error != ''
	OR maker.instagram_error != ''
	OR maker.twitter_error != ''
	OR maker.pinterest_error != ''
	OR maker.youtube_error != ''
	ORDER BY maker.maker_name ASC;