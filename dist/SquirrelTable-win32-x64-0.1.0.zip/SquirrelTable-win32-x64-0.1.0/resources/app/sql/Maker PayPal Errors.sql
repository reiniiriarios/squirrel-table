SELECT p.* FROM (
	SELECT
		maker.maker_id,
		maker.email,
		maker.maker_name,
		maker.first_name,
		maker.last_name,
		maker.paypal_email,
		CASE
			WHEN maker.uppc_referral_id IS NOT NULL AND maker.uppc_merchant_id IS NULL THEN 'merchant id missing'
			WHEN maker.uppc_referral_id IS NOT NULL AND maker.paypal_email = '' THEN 'connected, email missing'
			WHEN maker.uppc_referral_id IS NOT NULL AND maker.paypal_email IS NULL THEN '(json error) connected, email missing'
			WHEN maker.paypal_email LIKE '% %' THEN 'extra spaces in paypal email address'
			ELSE '' END
			AS paypal_error,
		CASE
			WHEN maker.uppc_referral_id IS NULL AND maker.paypal_email = '' THEN 'email missing'
			WHEN maker.uppc_referral_id IS NULL AND maker.paypal_email IS NULL THEN '(json error) email missing'
			WHEN maker.uppc_referral_id IS NOT NULL THEN 'connected'
			ELSE 'not connected' END
			AS paypal_status,
		store.name AS region_name,
		users.logdate AS last_login,
		COUNT(product.product_id) AS num_products,
		SUM(product_status.value = 1) AS num_products_enabled
		FROM (SELECT
			m.vendor_id AS maker_id,
			m.email,
			m.vendor_name AS maker_name,
			m.uppc_referral_id,
			m.uppc_merchant_id,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.firstname')) AS first_name,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.lastname')) AS last_name,
			JSON_UNQUOTE(JSON_EXTRACT(m.custom_vars_combined,'$.payout_paypal_email')) AS paypal_email,
			m.store_id
			FROM udropship_vendor m
			WHERE m.status = 'A'
		) AS maker
		LEFT JOIN udropship_vendor_product_assoc product
		ON maker.maker_id = product.vendor_id
		LEFT JOIN catalog_product_entity product_entity
		ON product.product_id = product_entity.entity_id
		LEFT JOIN catalog_product_entity_int product_status
		ON product_entity.row_id = product_status.row_id AND product_status.attribute_id = 97
		LEFT JOIN store
		ON store.store_id = maker.store_id
		LEFT JOIN admin_user users
		ON users.udropship_vendor = maker.maker_id
		GROUP BY maker.maker_id
	) p
	WHERE num_products > 0
	ORDER BY p.paypal_error DESC, p.paypal_status DESC, p.maker_id ASC;